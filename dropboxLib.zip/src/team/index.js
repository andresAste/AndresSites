var DropboxTeam = require('./dropbox-team');

module.exports = DropboxTeam;
